class Usuarios:
    def __init__(self, cedula, nickname, nombre, apellido, clave):
        self.cedula = cedula
        self.nickname = nickname
        self.nombre = nombre
        self.apellido = apellido
        self.clave = clave

    usuarios_map = {}

    @classmethod
    def agregar_usuario(cls, usuario):
        cls.usuarios_map[usuario.nickname] = usuario

    @classmethod
    def validar(cls, nickname, clave):
        usuario = cls.usuarios_map.get(nickname)
        if usuario and usuario.clave == clave:
            return True
        return False
